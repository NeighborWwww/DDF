
public interface Sortable {
	
	public boolean lessThan(Sortable a);


}
