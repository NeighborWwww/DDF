
public interface HighIncome {
	public boolean fatCat();
	

}
